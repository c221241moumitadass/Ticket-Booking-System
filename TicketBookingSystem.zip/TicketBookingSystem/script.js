// Variables to store passenger details
let passengers = [];

// Add Passenger
document.getElementById("addPassenger").addEventListener("click", () => {
    const name = document.getElementById("name").value;
    const age = parseInt(document.getElementById("age").value);
    if (!name || isNaN(age)) {
        alert("Please enter valid details!");
        return;
    }
    passengers.push({ name, age, arrivalTime: passengers.length });
    updatePassengerList();
    document.getElementById("name").value = "";
    document.getElementById("age").value = "";
});

// Update Passenger List
function updatePassengerList() {
    const list = document.getElementById("passengerList");
    list.innerHTML = passengers
        .map((p, i) => `<div>${i + 1}. ${p.name} (Age: ${p.age})</div>`)
        .join("");
}

// Process Booking
document.getElementById("processBooking").addEventListener("click", () => {
    const algorithm = document.getElementById("algorithm").value;
    if (algorithm === "fcfs") {
        processFCFS();
    } else {
        processPriority();
    }
});

// FCFS Scheduling
function processFCFS() {
    displayResults(passengers);
}

// Priority Scheduling
function processPriority() {
    const sortedPassengers = [...passengers].sort((a, b) => b.age - a.age);
    displayResults(sortedPassengers);
}

// Display Results
function displayResults(sortedPassengers) {
    let waitingTime = 0;
    let totalWaitingTime = 0;
    let totalTurnaroundTime = 0;
    const results = sortedPassengers.map((p, i) => {
        totalWaitingTime += waitingTime;
        totalTurnaroundTime += waitingTime + 1;
        const result = `${i + 1}. ${p.name} (Age: ${p.age}) - Waiting Time: ${waitingTime}`;
        waitingTime++;
        return result;
    });
    document.getElementById("results").innerHTML = `
        <h3>Booking Order:</h3>
        ${results.join("<br>")}
        <h3>Average Waiting Time: ${(totalWaitingTime / sortedPassengers.length).toFixed(2)}</h3>
        <h3>Average Turnaround Time: ${(totalTurnaroundTime / sortedPassengers.length).toFixed(2)}</h3>
    `;
}
